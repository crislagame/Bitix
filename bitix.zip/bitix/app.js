var app = angular.module('meuApp',[]);
app.controller('meuController', function($scope, $http){
  //$scope.plataformas=[{sku:'TBT01',nome:'Tablet',descricao:'Chip para navegar à vontade'},{sku:'CPT02',nome:'Computador',descricao:'Seu computador|Sempre conectado'},{sku:'WF03',nome:'WI-FI',descricao:'Internet WI-FI para|casa toda'}];


  //capturando os dados vindos da API JSON
  var httpPromise = $http({
     method: 'GET',
     url: 'http://private-59658d-celulardireto2017.apiary-mock.com/plataformas'
  }).then(function onFulfilledHandler(response) {

    $scope.plataformas = response.data.plataformas

    console.log("Este é o objeto temporário do successCallback das plataformas: ", $scope.plataformas);

    //retorna o objeto para o encadeamento
    return $scope.plataformas;

  });

  $scope.sku = null;

  $scope.update = function() {
   console.log($scope.sku);

   // usando a resposta $scope.sku aqui

   var httpPromise = $http({
      method: 'GET',
      url: 'http://private-59658d-celulardireto2017.apiary-mock.com/planos/'+$scope.sku
   }).then(function onFulfilledHandler(response) {

     $scope.planos = response.data.planos

     console.log("Este é o objeto temporário do successCallback dos planos: ", $scope.planos);

     //retorna o objeto para o encadeamento
     return $scope.planos;

   });
 }

});
