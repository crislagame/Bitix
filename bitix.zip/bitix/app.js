var app = angular.module('meuApp',[]);
app.controller('meuController',function($scope, $http){
  //$scope.plataformas=[{sku:'TBT01',nome:'Tablet',descricao:'Chip para navegar à vontade'},{sku:'CPT02',nome:'Computador',descricao:'Seu computador|Sempre conectado'},{sku:'WF03',nome:'WI-FI',descricao:'Internet WI-FI para|casa toda'}];


      //save httpPromise for chaining
      var httpPromise = $http({
         method: 'GET',
         url: 'http://private-59658d-celulardireto2017.apiary-mock.com/plataformas'
      }).then(function onFulfilledHandler(response) {

         $scope.plataformas = response.data.result;

         console.log("Este é o objeto temporário do successCallback: ", $scope.plataformas);

         //return object for chaining
         return $scope.plataformas;

      });

  $scope.sku = null;

});
