var gulp = require('gulp');
var concat = require('gulp-concat');

var js = [
  './node_modules/angular/angular.js',
  './node_modules/bootstrap/dist/js/bootstrap.js'
];
//Cria a tarefa defalt
gulp.task('default',function(){
  gulp.src(js)
    .pipe(concat('script.js'))
    .pipe(gulp.dest('./js/'));
});
